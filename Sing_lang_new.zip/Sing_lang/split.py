import os
import shutil
from sklearn.model_selection import train_test_split

# Path to your dataset folder (adjust to 'train/labels' if working with labels)
dataset_dir = r"C:\Users\Qualitas\Downloads\Sing lang.v3i.yolov5pytorch\train\labels"
output_dir = r"C:\Users\Qualitas\Downloads\Sing lang.v3i.yolov5pytorch\split_dataset"

# Classes
classes = ['Hello', 'IloveYou', 'No', 'Please', 'Thanks', 'Yes']

# Split ratios
train_ratio = 0.7
val_ratio = 0.15
test_ratio = 0.15

# Create output directories
for split in ['train', 'val', 'test']:
    for class_name in classes:
        os.makedirs(os.path.join(output_dir, split, class_name), exist_ok=True)

# Process each class
for class_name in classes:
    # Collect all files starting with the class name
    class_files = [f for f in os.listdir(dataset_dir) if f.startswith(class_name)]
    print(f"Class: {class_name}, Files: {class_files}")  # Debugging line

    if not class_files:
        print(f"No files found for class: {class_name}")
        continue

    # Split the files
    train_files, temp_files = train_test_split(class_files, test_size=(1 - train_ratio), random_state=42)
    val_files, test_files = train_test_split(temp_files, test_size=test_ratio / (test_ratio + val_ratio), random_state=42)

    # Copy files to respective directories
    for file in train_files:
        shutil.copy(os.path.join(dataset_dir, file), os.path.join(output_dir, 'train', class_name, file))
    for file in val_files:
        shutil.copy(os.path.join(dataset_dir, file), os.path.join(output_dir, 'val', class_name, file))
    for file in test_files:
        shutil.copy(os.path.join(dataset_dir, file), os.path.join(output_dir, 'test', class_name, file))

print("Dataset split completed!")
